//
//  ViewController.swift
//  calculateQ
//
//  Created by student on 10/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amount: UITextField!
    
    
    @IBOutlet weak var discount: UITextField!
    
    
    @IBOutlet weak var total: UILabel!
    @IBOutlet var dis: UIView!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var displaylabel: UILabel!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calsubmit(_ sender: UIButton) {
        var text = amount.text!
        var text1 =  discount.text!
        
        price.text = "the price is \(amount.text)"
        
 
    }
    
    }
    


