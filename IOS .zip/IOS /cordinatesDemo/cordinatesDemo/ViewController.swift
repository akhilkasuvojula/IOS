//
//  ViewController.swift
//  cordinatesDemo
//
//  Created by student on 10/12/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

