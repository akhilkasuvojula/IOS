//
//  ViewController.swift
//  CourseDisplay
//
//  Created by student on 9/21/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var curNum: UILabel!
    
 
    @IBOutlet weak var ImageDisplay: UIImageView!
    
    @IBOutlet weak var curTile: UILabel!
    
    var imageNumber = 0
    
    @IBOutlet weak var curSem: UILabel!
    
    @IBOutlet weak var prevLabel: UIButton!
    
    var courses = [["44555", "Network Security", "fall"],
                      ["44643", "iOS", "spring"],
                      ["44656", "Streaming Data", "summer"]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        prevLabel.isEnabled = false;
        curNum.text = courses[0][0]
        curTile.text = courses[0][1]
        curSem.text = courses[0][2]
        ImageDisplay.image = UIImage(named:courses[0][1])
    }

    @IBAction func next(_ sender: Any) {
        prevLabel.isEnabled = true;
        curNum.text = courses[1][0]
        curTile.text = courses[1][1]
        curSem.text = courses[1][2]
        ImageDisplay.image = UIImage(named: "img02")
        imageNumber += 1
        
        
    }
    @IBAction func previous(_ sender: Any) {
        prevLabel.isEnabled = true;
        curNum.text = courses[1][0]
        curTile.text = courses[1][1]
        curSem.text = courses[1][2]
        ImageDisplay.image = UIImage(named: "img02")
        if imageNumber == courses.count-1{
            next
        }
        
           }
    }
    


