//
//  AutoCompleteSearchResponse.swift
//  RecipeApp
//
//  Created by student on 12/4/21.
//

import Foundation

struct AutoCompleteSearchResponse: Codable {
    let id: Int
    let title: String
}
