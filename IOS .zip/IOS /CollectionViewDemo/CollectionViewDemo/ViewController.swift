//
//  ViewController.swift
//  CollectionViewDemo
//
//  Created by student on 11/11/21.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let Cell = CollectionViewOutlet.dequeueReusableCell(withReuseIdentifier:"Movie", for: indexPath)as! MovieCollectionViewCell
        
        Cell.assignMovie(with:movies[indexPath.row])
        
        return Cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDeatils(index: indexPath)
            
        }
    func assignMovieDeatils(index:IndexPath)
    {
        TittleOutlet.text = "Movie Name:\(movies[index.row].title)"
        TittleOutlet.text = "Movie Name:\(movies[index.row].title)"
        TittleOutlet.text = "Movie Name:\(movies[index.row].title)"
        TittleOutlet.text = "Movie Name:\(movies[index.row].title)"
    }
    
    

    @IBOutlet weak var CollectionViewOutlet: UICollectionView!
    
    @IBOutlet weak var TittleOutlet: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        CollectionViewOutlet.delegate = self
        CollectionViewOutlet.dataSource = self
    }


}

