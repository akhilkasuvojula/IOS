//
//  ViewController.swift
//  FoodRecipeApp
//
//  Created by student on 11/10/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

