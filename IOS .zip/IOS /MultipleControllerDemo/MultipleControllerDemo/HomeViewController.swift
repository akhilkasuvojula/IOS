//
//  ViewController.swift
//  MultipleControllerDemo
//
//  Created by student on 10/19/21.
//

import UIKit

class HomeViewController: UIViewController {

   
    @IBOutlet weak var AmountOutlet: UITextField!
    
    @IBOutlet weak var DiscountOutlet: UITextField!
    var priceaftertDisc = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
   @IBAction func CalcButtonPressed(_ sender: Any) {
    let amount = Double(AmountOutlet.text!)
    let discount = Double(DiscountOutlet.text!)
     priceaftertDisc = amount! -  (amount!*discount!/100)
    
      print(priceaftertDisc)

  }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destination = segue.destination
        as!
        ResultViewController
        destination.Amount = AmountOutlet.text!
        destination.discount = DiscountOutlet.text!
        
        destination.afterDiscount =  String(priceaftertDisc)
    }
    
}

