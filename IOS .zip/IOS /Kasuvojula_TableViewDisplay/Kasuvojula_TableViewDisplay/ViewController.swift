//
//  ViewController.swift
//  Kasuvojula_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

