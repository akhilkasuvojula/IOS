//
//  ViewController.swift
//  calculateQ
//
//  Created by student on 10/14/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amount: UITextField!
    
    
    @IBOutlet weak var discount: UITextField!
    
    
    @IBOutlet weak var displaylabel: UILabel!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calsubmit(_ sender: UIButton) {
        var text = amount.text!
        var text1 =  discount.text!
 calsubmit(value:Double,percentageVal:Double)->Double{
            let val = value * percentageVal
            return val / 100.0
        }
        
    }
    
    }
    


