//
//  DisplayImagesViewController.swift
//  Kasuvojula_TableViewDisplay
//
//  Created by student on 11/19/21.
//

import UIKit

class DisplayImagesViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var displayLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func button(_ sender: UIButton) {
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
