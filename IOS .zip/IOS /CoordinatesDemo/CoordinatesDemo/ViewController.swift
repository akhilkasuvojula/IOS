//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by student on 10/7/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minx = ImageView.frame.minX
        let miny = ImageView.frame.minY
        print(minx, miny)
        //
        let maxx = ImageView.frame.maxX
        let maxy = ImageView.frame.maxY
        print(maxx, maxy)
        
        let midx = ImageView.frame.midX
        let midy = ImageView.frame.midY
        print(midx, midy)
        
        let w = ImageView.frame.width
        let h = ImageView.frame.height
        print(w, h)
        // change the location of image to bottom right of the screen
        ImageView.frame.origin.x = 314
        ImageView.frame.origin.y = 796
        
        //change the location of imageview to bottom left of the screen
        ImageView.frame.origin.x = 0
        ImageView.frame.origin.y = 718
        
            //change the location of imageview to top right of the screen
            ImageView.frame.origin.x = 314
            ImageView.frame.origin.y = 0
            //change the location of imageview to top left of the screen
            ImageView.frame.origin.x = 0
            ImageView.frame.origin.y = 0
            //change the location of imageview to center of the screen 414-100
            ImageView.frame.origin.x = 157
            ImageView.frame.origin.y = 398
    }

    
        
    @IBAction func Submitbuttonclicked(_ sender: UIButton) {
        
        var w = ImageView.frame.width; w += 100
        var h = ImageView.frame.height; h += 100
        
        
        let x = ImageView.frame.origin.x-50
        let y = ImageView.frame.origin.y-50
        let imageFrame = CGRect(x: x, y: y, width: w, height: h)
        
       // ImageView.frame = imageFrame
        
        
      //  UIView.animate(withDuration: 1,delay:3, animations:{
        //    self.ImageView.frame = imageFrame
      //  })
        
        UIView.animate(withDuration: 1,delay: 2,usingSpringWithDamping: 0.6,initialSpringVelocity: 20,animations:{
            self.ImageView.frame = imageFrame
        })
    }
    
    
    
    
}

