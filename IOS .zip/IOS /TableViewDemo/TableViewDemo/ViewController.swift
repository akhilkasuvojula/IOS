//
//  ViewController.swift
//  TableViewDemo
//
//  Created by student on 11/2/21.
//

import UIKit

//start of class
class Product{
    var productName : String?
    var productCategory : String?
    
    init (prodName : String, prodCategory: String){
        self.productName = prodName
        self.productCategory = prodCategory
    }
}// end of the class



class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //we have to populate the cells from the data source
        let cell = TableViewOutlet.dequeueReusableCell(withIdentifier: "ReusableCell", for: indexPath)
        // ASSIGN THE DATA TO THE CELL
        cell.textLabel?.text = productsArray[indexPath.row
        ].productName
        
        return cell
    }
    

    @IBOutlet weak var TableViewOutlet: UITableView!
    
    var  productsArray = [Product]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        TableViewOutlet.delegate = self
        TableViewOutlet.dataSource = self
        
        let p1 = Product(prodName: "MacBookAir", prodCategory: "Laptop")
        productsArray.append(p1)
        
        let p2 = Product(prodName: "iphone", prodCategory: "Cellphone")
        productsArray.append(p2)
        
        let p3 = Product(prodName: "ipad", prodCategory: "Tablet")
        productsArray.append(p3)
        
        let p4 = Product(prodName: "ipod", prodCategory: "earphone")
        productsArray.append(p4)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue"{
            let destination = segue.destination
            as!
                ResultViewController; destination.product = productsArray[(TableViewOutlet.indexPathForSelectedRow?.row)!]
        }
    }

}

